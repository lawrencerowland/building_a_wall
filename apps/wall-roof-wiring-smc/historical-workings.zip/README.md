# Historical wiring workings

These are the source workings for the September 2026 three-essay consolidation.
Start with the maintained essays and source-map.html. This recovery archive is
not an alternative current tutorial: it intentionally retains failed drafts,
duplicate code, a truncated SVG and historical model errors for provenance.

Seven standalone artifacts retain exact source bytes. Three prose records are
public derivatives: private conversation identifiers, internal routing/output
paths, unresolvable attachment citation markup and internal generation commentary
were removed. All useful construction and mathematical working remains. The
manifest gives both original and public hashes; these three are not exact raw
conversation backups. No source PDF or private database record is included.

The original binary attachment was not present in these folders; the shell DOT
was recoverable as pasted text. A historical failed file-creation attempt is not
evidence of a saved file. The standalone DOT is a one-worker serial alternative;
the earlier two-worker scenario has a different interface.
